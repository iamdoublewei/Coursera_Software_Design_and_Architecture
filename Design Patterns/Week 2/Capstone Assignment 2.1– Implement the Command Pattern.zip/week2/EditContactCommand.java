package com.example.sharingapp;

import android.content.Context;

public class EditContactCommand extends Command {
    private ContactList list;
    private Contact oldContact;
    private Contact newContact;
    private Context context;

    public EditContactCommand(ContactList list, Contact oldContact, Contact newContact, Context context) {
        this.list = list;
        this.oldContact = oldContact;
        this.newContact = newContact;
        this.context = context;
    }

    @Override
    void execute() {
        list.deleteContact(oldContact);
        list.addContact(newContact);
        setIsExecuted(list.saveContacts(context));
    }
}
