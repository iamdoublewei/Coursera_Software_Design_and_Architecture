package com.example.sharingapp;

import android.content.Context;

public class AddContactCommand extends Command {

    private ContactList list;
    private Contact contact;
    private Context context;

    public AddContactCommand(ContactList list, Contact contact, Context context) {
        this.list = list;
        this.contact = contact;
        this.context = context;
    }

    @Override
    void execute() {
        list.addContact(contact);
        setIsExecuted(list.saveContacts(context));
    }
}
