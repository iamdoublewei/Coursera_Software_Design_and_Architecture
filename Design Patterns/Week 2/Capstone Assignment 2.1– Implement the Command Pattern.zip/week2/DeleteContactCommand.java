package com.example.sharingapp;

import android.content.Context;

public class DeleteContactCommand extends Command {

    private ContactList list;
    private Contact contact;
    private Context context;

    public DeleteContactCommand(ContactList list, Contact contact, Context context) {
        this.list = list;
        this.contact = contact;
        this.context = context;
    }

    @Override
    void execute() {
        list.deleteContact(contact);
        setIsExecuted(list.saveContacts(context));
    }
}
